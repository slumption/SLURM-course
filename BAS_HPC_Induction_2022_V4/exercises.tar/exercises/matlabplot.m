x = 0:0.05:5;
y = sin(x.^2);
figure
plot(x,y)
f = gcf;
exportgraphics(f,'matlabplot.png')

